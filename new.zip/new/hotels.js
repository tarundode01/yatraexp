// JavaScript to handle "Book Now" button click
document.getElementById('bookNowBtn').addEventListener('click', function() {
    alert('Thank you for booking with Yatra Express. Redirecting to booking form...');
    // Redirecting to booking form page (you can modify this URL as needed)
    window.location.href = 'booking.html';
});
